import { Resource } from "@/types/resource";

export const mockResources: Resource[] = [];
